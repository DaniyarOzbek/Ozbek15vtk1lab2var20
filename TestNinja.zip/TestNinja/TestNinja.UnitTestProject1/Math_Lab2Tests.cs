﻿using System;
using TestNinja.Fundamentals;
using NUnit.Framework;
using System.Linq;

namespace TestNinja.UnitTests
{
    [TestFixture]
    public class Math_Lab2Tests
    {
        private Math_Lab2 _math;
        [SetUp]
        public void SetUp()
        {
            _math = new Math_Lab2();
        }
        [Test]
        [TestCase(2, 1, 2)]
        [TestCase(1, 2, 2)]
        [TestCase(1, 1, 1)]
        public void Max_WhenCalled_ReturnTheGreaterArgument(int a, int b, int expectedResult)
        {

            var result = _math.Max(a, b);
            Assert.That(result == expectedResult);
        }
        /*[Test]
        public void Max_SecondArgumentIsGreater_ReturnTheSecondArgument()
         {

             var result = _math.Max(1, 2);
             Assert.That(result, Is.EqualTo(2));
         }
         [Test]
         public void Max_ArgumentIsEqual_ReturnTheSameArgument()
         {

             var result = _math.Max(1, 1);
             Assert.That(result, Is.EqualTo(1));
         }*/
        [Test]
        [TestCase(2, 1, 3)]
        [TestCase(1, 2, 3)]
        [TestCase(1, 1, 5)]
        public void Add_WhenCalled_Sum(int a, int b, int expectedResult)
        {

            var result = _math.Add(a, b);
            Assert.That(result == expectedResult);
        }

        [Test]
        public void GetoddNumbers_LimitsGreaterThanZero_ReturnOddNumbersUpToLimit()
        {
            var result = _math.GetOddNumbers(5);
            //Проверка что массив не пустой
            Assert.That(result, Is.Not.Empty);
            //Количество элементов в массиве = 3(Alt+Enter)
            Assert.That(result.Count(), Is.EqualTo(3));

            //Проверка что массав содержить число 1
            Assert.That(result, Does.Contain(1));
            //Проверка что массав содержить число 3
            Assert.That(result, Does.Contain(3));
            //Проверка что массав содержить число 5
            Assert.That(result, Does.Contain(5));

            // Проверка на совпадение всего массива целиком
            Assert.That(result, Is.EquivalentTo(new[] { 1, 3, 5 }));
            //Проверка что массав отсартирован
            Assert.That(result, Is.Ordered);
            //Проверка что массав содержит уникальные,не повторяющиеся значения
            Assert.That(result, Is.Unique);
        }
    }
}
