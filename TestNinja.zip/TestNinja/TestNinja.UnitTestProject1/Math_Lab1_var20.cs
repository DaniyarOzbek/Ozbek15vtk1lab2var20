﻿using System;
using NUnit.Framework;

namespace TestNinja.UnitTestProject1
{
    [TestFixture]

    //Assert

    public class Math_Lab1_var20
    {
        [Test]
        public void IsSumDivisibleBy9_13and5_ReturnsTrue()
        {
            //Arrange
            var math_Lab1 = new Fundamentals.Math_Lab1();
            //Act
            var result = math_Lab1.IsSumDivisibleBy9(13, 5);
            //Assert
            Assert.IsTrue(result);
            Assert.That(result, Is.True);
            Assert.That(result == true);

        }

        [Test]
        public void IsSumDivisibleBy9_23and5_ReturnsFalse()
        {
            //Arrange
            var math_Lab1 = new Fundamentals.Math_Lab1();
            //Act
            var result = math_Lab1.IsSumDivisibleBy9(23, 5);
            //Assert
            Assert.IsTrue(result);
            
            Assert.That(result, Is.True);
            Assert.That(result == true);
        }
    }
}
